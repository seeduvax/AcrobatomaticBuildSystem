# generated: ABS-3.4.27 fred@fred-inspiron 2026-02-17 19:13:25+0100
_app_HtmlToBook_dir:=$(dir $(lastword $(MAKEFILE_LIST)))

_app_HtmlToBook_version:=1.0.0
_app_HtmlToBook_uselib:=
_app_HtmlToBook_modules:=htmltobook



_module_HtmlToBook_htmltobook_dir:=$(_app_HtmlToBook_dir)
_module_HtmlToBook__extra_dir:=$(_app_HtmlToBook_dir)
_app_HtmlToBook_alluselib:=$(sort $(_app_HtmlToBook_uselib) )

-include $(wildcard $(_app_HtmlToBook_dir)/.abs/index_*.mk)
$(eval $(call extlib_import_template,HtmlToBook,$(_app_HtmlToBook_version),$(_app_HtmlToBook_alluselib)))


