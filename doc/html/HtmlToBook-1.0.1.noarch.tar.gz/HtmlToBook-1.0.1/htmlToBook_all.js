
/**
 * Copyright 2026 fred322
 * https://github.com/fred322
 * 
 */

class DomUtils {
    constructor() {
        this.a4Height = 29.7;
        this.a4Width = 21.0;
        this._cmToPixel = 0;
        this._pageHeight = 0;
        
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        this.debug = urlParams.get("debug") == "true";
    }

    init() {
        // create fake page to have dimensions of pages.
        let element = document.createElement("div");
        element.style = "height: 2px; width: 210mm; position: absolute; top: 0; left: 0;";
        document.body.appendChild(element);
        this._cmToPixel = element.offsetWidth / 21.0;

        this.isLandscape = document.body.classList.contains("landscape");
        this._pageHeight = this.cmToPixel(this.isLandscape ? this.a4Width : this.a4Height);
    }

    isDebug() {
        return this.debug;        
    }

    /**
     * The value of given variable in meta.
     * @param {string} varName 
     */
    getMetaValue(varName) {
        let metas = document.getElementsByTagName("meta");
        for (let meta of metas) {
            if (meta.getAttribute("name") == varName) {
                return meta.getAttribute("content");
            }
        }
        return null;
    }

    getPageHeight() {
        return this._pageHeight;
    }

    createElement(name, options) {
        let res = document.createElement(name);
        if (options.classes != null) {
            for (let element of options.classes) {
                res.classList.add(element);
            }
        }
        if (options.height != null) {
            res.setAttribute("style", "height: " + options.height + "px");
        }
        if (options.marginTop != null) {
            res.setAttribute("style", "margin-top: " + options.marginTop + "px");
        }
        if (options.marginBottom != null) {
            res.setAttribute("style", "margin-bottom: " + options.marginBottom + "px");
        }
        return res;
    }

    cmToPixel(cm) {
        return cm * this._cmToPixel;
    }

    pixelToPdfPt(pixel) {
        // 28,35 pt => 1 cm
        return (pixel * 28.35) / this._cmToPixel;
    }
    /**
     * Get the absolute position of given element.
     * @param {Element} element 
     * @returns 
     */
    getAbsolutePosition(element) {
        return element.offsetTop + (element.offsetParent != null ? this.getAbsolutePosition(element.offsetParent) : 0);
    }

    /**
     * Get the bottom absolute position of given element.
     * @param {Element} element 
     * @returns 
     */
    getBottomAbsolutePosition(element) {
        return this.getAbsolutePosition(element) + element.offsetHeight + parseFloat(window.getComputedStyle(element).marginBottom);
    }

    /**
     * Get the page number from given element.
     * @param {Element} element 
     * @returns 
     */
    getPageNumber(element) {
        return Math.floor(this.getAbsolutePosition(element) / this._pageHeight) + 1;
    }

    /**
     * Get the position in page for given element.
     * @param {Element} element 
     */
    getPositionInPage(element) {
        return this.getAbsolutePosition(element) - (this.getPageNumber(element) - 1) * this._pageHeight;
    }
}

let domUtils = new DomUtils();

/**
 * Copyright 2026 fred322
 * https://github.com/fred322
 * 
 */

class DomRunner {
    constructor(element) {
        this.element = element;
        this.current = null;
        this.currentIndex = 0;
    }

    findNext(posY, filter, options) {
        if (this.current != null && this.current.element != null) {
            if (domUtils.getBottomAbsolutePosition(this.current.element) >= posY) {
                let found = this.current.findNext(posY, filter, options);
                if (found != null) {
                    return options.getUpper == true && found == this.current.element.children[0] ?
                        this.current.element : found;
                }
            }
            this.current.element = null;
            this.currentIndex++;
        }
        for (; this.currentIndex < this.element.children.length; this.currentIndex++) {
            let element = this.element.children[this.currentIndex];
            if (domUtils.getBottomAbsolutePosition(element) >= posY) {
                if (filter(element)) {
                    if (this.current == null) {
                        this.current = new DomRunner();
                    }
                    this.current._setElement(element);
                    let found = this.current.findNext(posY, filter, options);
                    if (found != null) {
                        return options.getUpper == true && found == this.current.element.children[0] ?
                            this.current.element : found;
                    }
                }
                return element;
            }
        }
        return this.element;
    }
    _setElement(element) {
        this.element = element;
        this.currentIndex = 0;
        if (this.current != null) {
            this.current.element = null;
        }
    }
};


/**
 * Copyright 2026 fred322
 * https://github.com/fred322
 * 
 */

class Summary {
    constructor(articleNode) {
        this.sections = [];
        this.articleNode = articleNode;
        this._lastAnchorId = 0;
        this._isNumberedSections = domUtils.getMetaValue("numberedSections") != "false";
    }

    /**
     * Indicates if section must be numbered.
     * @returns true if sections must be counted
     */
    isNumberedSections() {
        return this._isNumberedSections;
    }

    createSummary() {
        // run across section to find all titles and add numbers
        let summary = document.getElementById("toc");
        this.analyseSections(this.articleNode);
        if (summary != null) {
            this.printSummaryEntry(summary, this.sections, "");
        }
        else {
            console.log("No 'toc' element. The table of content will not be generated");
        }
    }
    analyseSections(rootNode) {
        if (rootNode != null) {
            this._findSections(rootNode, this.sections);
        }
    }
    /**
     * 
     * @param {Element} summary 
     * @param {Array} sections
     * @param {String} number 
     */
    printSummaryEntry(summary, sections, number) {
        let count = 1;
        if (sections == null) return;
        for (let section of sections) {
            let titleElement = this._findTitleElement(section.element);
            section.title = titleElement.innerText;
            let linkElement = document.createElement("a");
            let anchor = section.element.getAttribute("id");
            if (anchor == null) {
                anchor = "__anchor_" + this._lastAnchorId;
                this._lastAnchorId = this._lastAnchorId + 1;
                section.element.setAttribute("id", anchor);
            }
            linkElement.setAttribute("href", "#" + anchor);
            linkElement.classList.add("toc_item");

            let newNumber = (number.length != 0 ? number + "." : "") + count;
            section.number = newNumber;
            if (this.isNumberedSections()) {
                linkElement.innerText = newNumber + " - " + section.title;
                titleElement.innerText = newNumber + " " + titleElement.innerText;
            }
            else {
                linkElement.innerText = section.title;
            }
            let pageSpan = document.createElement("span");
            pageSpan.innerText = domUtils.getPageNumber(section.element);
            pageSpan.classList.add("toc_item_page_number");
            section.pageNumberElement = pageSpan;
            linkElement.appendChild(domUtils.createElement("span", { classes: ["toc_item_points" ]}));
            linkElement.appendChild(pageSpan);
            summary.appendChild(linkElement);

            this.printSummaryEntry(summary, section.children, newNumber);
            count++;
        }
    }

    updatePageNumbers() {
        this._updatePageNumbers(this.sections);
    }

    _findTitleElement(section) {
        for (let child of section.children) {
            if (child.innerText.length != 0) {
                return child;
            }
        }
        return "No title";
    }
    _updatePageNumbers(sections) {
        if (sections == null) return;
        for (let section of sections) {
            section.pageNumber = domUtils.getPageNumber(section.element);
            if (section.pageNumberElement != null) {
                section.pageNumberElement.innerText = section.pageNumber;
            }
            section.positionInPage = domUtils.getPositionInPage(section.element);
            this._updatePageNumbers(section.children);
        }
    }

    _findSections(parentNode, summary) {
        for (let child of parentNode.children) {
            if (child.tagName.toLowerCase() == "section") {
                let newElement = { element: child, children: [] };
                this._findSections(child, newElement.children);
                summary.push(newElement);
            }
        }
    }
}


/**
 * Copyright 2026 fred322
 * https://github.com/fred322
 * 
 */

class Bookmarks {
    /**
     * 
     * @param {Summary} summary 
     */
    constructor(summary) {
        this.summary = summary;
    }

    generateContent() {
        return "%!\n" + this._generateContent(this.summary.sections, 1);
    }

    _generateContent(sections, level) {
        let numberingSections = this.summary.isNumberedSections();
        let content = "";
        for (let section of sections) {
            if (section.title == null) continue;

            let countSubSignets = section.children.length;
            content += "[ /Title (" + (numberingSections == false ? "" : section.number + "-") + section.title + ")\n";
            content += "  /Page " + (section.pageNumber - 1) + "\n";
            content += "  /View [/XYZ 0 -" + domUtils.pixelToPdfPt(section.positionInPage) + " 0]\n";
            if (countSubSignets > 0) {
                content += "  /Count " + countSubSignets + "\n";
            }
            content += "  /OUT pdfmark\n\n";

            content += this._generateContent(section.children, level + 1);
        }
        return content;
    }
}


/**
 * Copyright 2026 fred322
 * https://github.com/fred322
 * 
 */

class PageSplitter {
    constructor(articleNode) {
        this.breakableTagNames = [ "div", "section", "p", "table", "tbody", "tr", "ul", "li" ];
        this.unbreakableTagNames = [ "a", "tr", "td", "th",
            "h1", "h2", "h3", "h4", "h5", "h6", "p", "pre"
        ];
        this.currentPage = 0;
        this.currentPageProperties = null;

        this.articleNode = articleNode;
    }

    isBreakableElement(element) {
        let elTagName = element.tagName.toLowerCase();
        for (let tagName of this.breakableTagNames) {
            if (elTagName == tagName) {
                return true;
            }
        }
        return false;
    }
    /**
     * Indicates if the element should not contains break page.
     * @param {Element} element 
     * @returns 
     */
    isUnbreakableElement(element) {
        if (element.classList.contains("unbreakable")) {
            return true;
        }
        let elTagName = element.tagName.toLowerCase();
        for (let tagName of this.unbreakableTagNames) {
            if (elTagName == tagName) {
                return true;
            }
        }
        return false;
    }
    findBreakableTagNames(child) {
        if (child == null || child.tagName.toLowerCase() == "body") return null;
        if (this.isBreakableElement(child)) return child;
        return this.findBreakableTagNames(child.parentElement);
    }
    
    breakPages() {
        let existingBreaks = document.getElementsByTagName("break_page");
        let domRunner = new DomRunner(this.articleNode);
        let element = this.articleNode.children[0];
        let lastElementBroken = null;
        this._initiateNextPage(element);
        let loopCount = 0;
        do {
            let posY = this.currentPageProperties.footerY;
            console.log("Look at pixel " + posY);

            if (this._breakPagesToPos(existingBreaks, posY) == 0) {
                element = domRunner.findNext(posY, 
                    (el) => { return !this.isUnbreakableElement(el)}, {
                        getUpper: true
                    });
                if (element != null && element != this.articleNode && 
                    element.tagName.toLowerCase() != "article") {
                    if (lastElementBroken != null && lastElementBroken == element) {
                        console.error("The element " + element.tagName + " cannot be broken. It should be too height");
                        break;
                    }
                    else if (element != null) {
                        console.log("Break at element");
                        this._breakAtElement(element);
                        lastElementBroken = element;
                    }
                }
                else {
                    element = null;
                    console.log("No element found");
                    break;
                }
            }
            if (domUtils.isDebug() && loopCount > 200) {
                console.error("Too many loops in debug mode");
                break;
            }
            loopCount++;
        } while (element != null);
    }

    /**
     * 
     * @param {Element[]} breaksElement 
     * @param {number} toPosY 
     */
    _breakPagesToPos(breaksElement, toPosY) {
        let count = 0;
        for (let element of breaksElement) {
            if (element.offsetHeight == 0 && !element.classList.contains("broken")) {
                if (domUtils.getAbsolutePosition(element) < toPosY) {
                    console.log("Break at break_page");
                    this._breakAtElement(element);
                    count++;
                }
                else {
                    break;
                }
            }
            element.classList.add("broken");
        }
        return count;
    }

    /**
     * 
     * @param {Element} element 
     */
    _breakAtElement(element) {
        let newBreak = document.createElement("div");
        newBreak.classList.add("break_page");
        element.parentElement.insertBefore(newBreak, element);
        // take position of newBreak because element is not necessary in DOM
        let leftSize = this.currentPageProperties.endOfPageY - domUtils.getAbsolutePosition(newBreak);
        leftSize = Math.min(domUtils.getPageHeight(), leftSize);
        newBreak.setAttribute("style", "height: " + leftSize + "px" );

        this._initiateNextPage(element);
    }

    _initiateNextPage(firstElement) {
        console.log("Creation new page");
        this._createNextPage();

        if (this.currentPageProperties.headerHeight > 0) {
            let newElement = domUtils.createElement("div", { height: this.currentPageProperties.headerHeight });
            newElement.classList.add("header_space");
            firstElement.parentElement.insertBefore(newElement, firstElement)
        }
    }
    _createNextPage() {
        this.currentPage = this.currentPage + 1;

        let headerDefault = document.getElementsByTagName("header")[0];
        let footerDefault = document.getElementsByTagName("footer")[0];

        let pagesWrapper = document.getElementById("pagesWrapper");
        if (pagesWrapper == null) {
            pagesWrapper = document.createElement("div");
            pagesWrapper.id = "pagesWrapper";
            document.body.insertBefore(pagesWrapper, this.articleNode);
        }
        let newPage = document.createElement("div");
        newPage.classList.add("page");
        newPage.classList.add("page_" + (this.currentPage));
        newPage.classList.add((this.currentPage % 2) == 0 ? "even" : "odd");
        pagesWrapper.appendChild(newPage);

        let expectedPosition = Math.round((this.currentPage - 1)* domUtils.cmToPixel(domUtils.a4Height));
        let realPosition = domUtils.getAbsolutePosition(newPage);
        console.debug("Expected: " + expectedPosition + "; Got " + realPosition);

        let header = null;
        if (headerDefault != null) {
            header = document.createElement("div");
            header.classList.add("header");
            header.innerHTML = headerDefault.innerHTML;
            newPage.appendChild(header);
        }
        let footer = null;
        if (footerDefault != null) {
            footer = document.createElement("div");
            footer.classList.add("footer");
            footer.innerHTML = footerDefault.innerHTML;
            newPage.appendChild(footer);

            // fix the height of footer, otherwise seems to have render issues in PDF.
            footer.setAttribute("style", "height: " + footer.offsetHeight + "px");
        }

        this.previousPage = newPage;

        let endOfPageY = domUtils.getAbsolutePosition(newPage) + newPage.offsetHeight;
        this.currentPageProperties = {
            /* Footer can be not shown => use newPage */
            footerY : endOfPageY - (footer != null ? footer.offsetHeight : 0),
            headerHeight: header != null ? header.offsetHeight : 0,
            footerHeight: footer != null ? footer.offsetHeight : 0,
            endOfPageY: endOfPageY
        }
    }
}


/**
 * Copyright 2026 fred322
 * https://github.com/fred322
 * 
 */



class HtmlToBook {
    constructor() {
        domUtils.init();
    }

    run() {
        if (domUtils.isDebug()) {
            document.body.classList.add("debug");
        }

        let articleNode = document.getElementsByTagName("article")[0];
        if (articleNode == null) {
            console.error("No 'article' node defined!");
            return;
        }

        let pageSplitter = new PageSplitter(articleNode);
        let summary = new Summary(articleNode);
        summary.createSummary();
        pageSplitter.breakPages();

        this.updatePageNumbers();
        summary.updatePageNumbers();

        let contentGs = new Bookmarks(summary).generateContent();
        let docElementGs = document.createElement("bookmarks");
        docElementGs.innerHTML = contentGs;
        docElementGs.style = "display: none";
        document.body.appendChild(docElementGs);
    }

    updatePageNumbers() {
        let article = document.getElementsByTagName("article")[0];
        let totalSize = domUtils.getAbsolutePosition(article) + article.offsetHeight;
        let pageSize = domUtils.cmToPixel(domUtils.a4Height);
        let pagesCount = Math.ceil(totalSize / pageSize);
        
        let pageNumberSpan = document.getElementsByClassName("pageNumber");
        for (let element of pageNumberSpan) {
            let pageNumber = Math.ceil(domUtils.getAbsolutePosition(element) / pageSize);
            element.innerText = pageNumber;
        }
        let pagesCountSpan = document.getElementsByClassName("pagesCount");
        for (let element of pagesCountSpan) {
            element.innerText = pagesCount;
        }
    }
}


/**
 * Copyright 2026 fred322
 * https://github.com/fred322
 * 
 */

let alreadyRun = false;
window.addEventListener("DOMContentLoaded", function() {
    if (alreadyRun) return;

    alreadyRun = true;
    new HtmlToBook().run();
});

