#include "subdir/inc.h"

int testSource() {
    return 2;
}