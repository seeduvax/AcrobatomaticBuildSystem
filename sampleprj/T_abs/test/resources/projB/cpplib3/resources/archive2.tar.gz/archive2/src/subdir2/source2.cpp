#include "subdir/inc2.h"

// need to be patched.
otoafafa()

int testSource2() {
    return 2;
}